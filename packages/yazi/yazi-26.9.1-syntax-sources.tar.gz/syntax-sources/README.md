Yazi v26.9.1 syntax source provenance
Prebuilt repository commit: 2d52c0b8b399aa476bfeff36a6256cffe76eb2a5

Source and license/notice files for the 64 pinned syntax submodules retained in
Yazi's filtered prebuilt syntax database. The package filters the published
SyntaxSet; it does not compile syntax definitions from these sources during RPM
builds.
Syntax definitions excluded from the bundled database:
- syntaxes/hosts: upstream repository is unavailable; no source snapshot
- syntaxes/less: no license grant found for the pinned snapshot
- syntaxes/livescript: upstream repository is unavailable; no source snapshot
- syntaxes/nginx: upstream repository is unavailable; no source snapshot
- syntaxes/verilog: no license grant found for the pinned snapshot

Included upstream repositories and pins:
- syntaxes/ada: https://github.com/wiremoons/ada-sublime-syntax.git (e2b8fd51756e0cc42172c1c3405832ce9c19b6b6)
- syntaxes/apache: https://github.com/colinta/ApacheConf.tmLanguage.git (163bc03ae8998a237dfb4be353d0aea198ea17f5)
- syntaxes/asciidoc: https://github.com/asciidoctor/sublimetext-asciidoc.git (e316a0a85c67c3edb73a46fc3a3ec4a9dfbbba40)
- syntaxes/assembly-arm: https://github.com/tvi/Sublime-ARM-Assembly.git (08f33d80ded128a708d83017148dba52ebdfb04a)
- syntaxes/awk: https://github.com/JohnNilsson/awk-sublime.git (e23926eca1b6a0bd0b572b7191aead9f77c748d1)
- syntaxes/cmake: https://github.com/zyxar/Sublime-CMakeLists.git (eb40ede56c2d4d5a4a129b2a5bc7095a2df46bb1)
- syntaxes/cmd-help: https://github.com/victor-gp/cmd-help-sublime-syntax.git (f28f82eafe9a08ea61a768645ed080af85aeec36)
- syntaxes/coffeescript: https://github.com/sustained/CoffeeScript-Sublime-Plugin.git (e08f9b8cdfc84e0456ae63dca7aaefb94bf06e24)
- syntaxes/crontab: https://github.com/michaelblyons/SublimeSyntax-Crontab.git (54f1fa7ff0c9d18aea3790555dba6e533ce3749b)
- syntaxes/crystal: https://github.com/crystal-lang-tools/sublime-crystal.git (360559200cfee8536eeefb97bad04c717628ad56)
- syntaxes/dart: https://github.com/elMuso/Dartlight.git (2734901b014191f5a7f71c3f48678adf31239098)
- syntaxes/docker: https://github.com/asbjornenge/Docker.tmbundle.git (0f6b7bc87acf684f7b0790fd480731ffb4615b87)
- syntaxes/dotenv: https://github.com/zaynali53/DotENV.git (58201ba2abbbe6a12b2f6d0595efea3b388c1e38)
- syntaxes/elixir: https://github.com/elixir-editors/elixir-sublime-syntax.git (bcee3db5f7abc5e5ae954fefb19a71f25605e873)
- syntaxes/elm: https://github.com/elm-community/SublimeElmLanguageSupport.git (e266d279c8074aa342f106554cfa87ebe839a782)
- syntaxes/email: https://github.com/mariozaizar/email.sublime-syntax.git (e89d09d440f342b753a490918f2c9777c64836b3)
- syntaxes/ethereum: https://github.com/davidhq/SublimeEthereum.git (443ffc37e7c373c66345d78fbe5c35729d5be6c0)
- syntaxes/fish: https://github.com/Phidica/sublime-fish.git (98316d4332936f74babb51cb56161410ae9d6e2c)
- syntaxes/fortran: https://github.com/315234/SublimeFortran.git (dcf4f24f1cecd9eebf6b1eb388e4f5db671a7b08)
- syntaxes/fsharp: https://github.com/hoest/sublimetext-fsharp.git (9e4645c6085871d6fe4ae8dbcbafe93cb155b074)
- syntaxes/glsl: https://github.com/euler0/sublime-glsl.git (59a5f8a3120358657cefdc4b830b4a883ebfbf77)
- syntaxes/gnuplot: https://github.com/hesstobi/sublime_gnuplot.git (04743470ff90237ba3fb34ccf77c2d256d611262)
- syntaxes/graphql: https://github.com/dncrews/GraphQL-SublimeText3.git (9b6f6d0a86d7e7ef1d44490b107472af7fb4ffaf)
- syntaxes/groff: https://github.com/carsonoid/sublime_man_page_support.git (651091c7e266e05c0a529b137b6efd43d717894c)
- syntaxes/http-request-response: https://github.com/keith-hall/http-request-response-syntax.git (93b93261bcd8b4fbb38d7e92d3cf3734f0814e31)
- syntaxes/ini: https://github.com/clintberry/sublime-text-2-ini.git (8dd3e316ada5cc8bffd3982bc2a9384345729f34)
- syntaxes/javascript: https://github.com/babel/babel-sublime.git (2b3608cd8b555e3e16df5585e11543085658afbd)
- syntaxes/jinja2: https://github.com/Martin819/sublime-jinja2.git (45355633d17ee562481ca1d2ad0e3502c238f58a)
- syntaxes/jq: https://github.com/zogwarg/SublimeJQ.git (687058289c1a888e0895378432d66b41609a84d8)
- syntaxes/jsonnet: https://github.com/gburiola/sublime-jsonnet-syntax.git (e2c917ed7d6020e2ba6c18b06c7278c094db03f7)
- syntaxes/julia: https://github.com/JuliaEditorSupport/Julia-sublime.git (98233f96d4827a1a576c0b8bf87a68b9c97e4306)
- syntaxes/kotlin: https://github.com/vkostyukov/kotlin-sublime-package.git (aeeed2780b04aea3d293c547c24cae27cafef0c5)
- syntaxes/lean: https://github.com/leanprover/vscode-lean.git (0696b292855c7cae711e00d69c79b2687c336f25)
- syntaxes/llvm: https://github.com/ioncodes/LLVM.tmBundle.git (274126faa9febfb649981cc97ecd499fcd7f5b90)
- syntaxes/media-Wiki: https://github.com/tosher/Mediawiker.git (89c25d4fa6c6224edbaf5f06794a03594bcccad0)
- syntaxes/ninja: https://github.com/pope/SublimeNinja.git (25830aaec9316b7fca6600000535214164525d7a)
- syntaxes/nix: https://github.com/wmertens/sublime-nix.git (9032bd613746b9c135223fd6f26a5fa555f18946)
- syntaxes/official: https://github.com/sublimehq/Packages.git (0a97be539c2732d7258ba4ec1450f7a3f4881b73)
- syntaxes/org-mode: https://github.com/jezcope/Org.tmbundle.git (bb6e5d848151135ab8f87bdcb997437b2308718a)
- syntaxes/powershell: https://github.com/PowerShell/EditorSyntax.git (c0372a1d2df136ca6b3d1a9f7b85031dedf117f9)
- syntaxes/protobuf: https://github.com/VcamX/protobuf-syntax-highlighting.git (fb556884b6712b98d424b4b17acaf25546900f45)
- syntaxes/puppet: https://github.com/russCloak/SublimePuppet.git (2a224343d2151b2896b6d9c48343919c06d1e695)
- syntaxes/purescript: https://github.com/tellnobody1/sublime-purescript-syntax.git (5acebc18503697be09df047591964e68e80fcf8e)
- syntaxes/qml: https://github.com/skozlovf/Sublime-QML.git (fdef17dbf8ef1e4e35a6bd3fab1e8a571d51dd49)
- syntaxes/racket: https://github.com/follesoe/sublime-racket.git (7df4479c079768edd994b20052761152e277af21)
- syntaxes/robot: https://github.com/andriyko/sublime-robot-framework-assistant.git (fcd3323b5631d4abe61e8e8c728d0f4329640a64)
- syntaxes/sass: https://github.com/braver/SublimeSass.git (3553dedfcf8690cd033d9dabe879e74ccd73936c)
- syntaxes/slim: https://github.com/slim-template/ruby-slim.tmbundle.git (3b1441f89fde40678c3c0ada6d75ce46417a35b6)
- syntaxes/sls: https://github.com/saltstack/sublime-text.git (f8a8cf90b1185acb63127dfdfe53379a6a16c0fd)
- syntaxes/ssh-config: https://github.com/robballou/sublimetext-sshconfig.git (e1012e9f13c6073f559b14206df2ede35720e884)
- syntaxes/strace: https://github.com/djuretic/SublimeStrace.git (3ec51e0bca39bf60cab7f96cecfc5d003c3ea59b)
- syntaxes/stylus: https://github.com/billymoon/Stylus.git (30908e3b5757d6cab4bf2ce660ef89b0c614cf62)
- syntaxes/svelte: https://github.com/corneliusio/svelte-sublime.git (16808be787bb2d879c819ee445cc1cbd8ce57a55)
- syntaxes/swift: https://github.com/quiqueg/Swift-Sublime-Package.git (fef17119ceef28a3c4b8cf72268d6192b595365d)
- syntaxes/systemveri-log: https://github.com/TheClams/SystemVerilog.git (7eca705e87f87b94478fe222fc91d54d488cc8e3)
- syntaxes/terraform: https://github.com/alexlouden/Terraform.tmLanguage.git (7faec10b4057b95bff82fb585730e560871d26c4)
- syntaxes/todo-txt: https://github.com/dertuxmalwieder/SublimeTodoTxt.git (071a004217f981152c78dc7a530536374a753d98)
- syntaxes/toml: https://github.com/jasonwilliams/sublime_toml_highlighting.git (fd0bf3e5d6c9e6397c0dc9639a0514d9bf55b800)
- syntaxes/twig: https://github.com/Anomareh/PHP-Twig.tmbundle.git (aedf955eba9753554815b2cbef5e072415e42068)
- syntaxes/typescript: https://github.com/Microsoft/TypeScript-Sublime-Plugin.git (90441845a32ebcbd54632a39688ee24b2a2f8984)
- syntaxes/varlink: https://github.com/varlink/syntax-highlight-varlink.git (04f30d4b831232ea23ffceb5b2da61e12dae5db6)
- syntaxes/viml: https://github.com/SalGnt/Sublime-VimL.git (ee85822cbed17858da1a556dec922b7da2a219bb)
- syntaxes/vue: https://github.com/vuejs/vue-syntax-highlight.git (6eb71bc6bba5e6a284b6d1d3154484da6f366e21)
- syntaxes/zig: https://github.com/ziglang/sublime-zig-language.git (1a4a38445fec495817625bafbeb01e79c44abcba)
